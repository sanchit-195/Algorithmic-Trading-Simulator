package com.trading.engine;
import com.trading.model.*;
import java.util.*;

public class MatchingEngine {
    private final Map<String, OrderBook> orderBooks;
    private final List<Trade> tradeLedger;

    public MatchingEngine() {
        this.orderBooks = new HashMap<>();
        this.tradeLedger = new ArrayList<>();
    }

    public void placeOrder(Order order) {
        String symbol = order.getSymbol();
        OrderBook orderBook = orderBooks.computeIfAbsent(symbol, OrderBook::new);
        
        System.out.println("Placing order: " + order);
        orderBook.addOrder(order);
        
        // Match karo aur trades generate karo
        List<Trade> newTrades = orderBook.matchOrders();
        tradeLedger.addAll(newTrades);
        
        for (Trade trade : newTrades) {
            System.out.println("Trade Generated: " + trade);
        }
    }

    public void printTradeLedger() {
        System.out.println("\n=== TRADE LEDGER ===");
        for (Trade trade : tradeLedger) {
            System.out.println(trade);
        }
    }
}