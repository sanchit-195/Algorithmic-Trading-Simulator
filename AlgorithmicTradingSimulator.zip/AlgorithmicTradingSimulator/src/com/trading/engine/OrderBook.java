package com.trading.engine;
import com.trading.model.*;
import java.util.*;

public class OrderBook {
    private final String symbol;
    
    // Buy orders (highest price first)
    private final PriorityQueue<Order> bids;
    // Sell orders (lowest price first)  
    private final PriorityQueue<Order> asks;
    
    // Fast order lookup ke liye
    private final Map<String, Order> orderMap;

    public OrderBook(String symbol) {
        this.symbol = symbol;
        
        // Buy orders ko highest price first sort karna
        this.bids = new PriorityQueue<>((o1, o2) -> {
            int priceCompare = Double.compare(o2.getPrice(), o1.getPrice());
            if (priceCompare != 0) return priceCompare;
            return o1.getTimestamp().compareTo(o2.getTimestamp());
        });
        
        // Sell orders ko lowest price first sort karna
        this.asks = new PriorityQueue<>((o1, o2) -> {
            int priceCompare = Double.compare(o1.getPrice(), o2.getPrice());
            if (priceCompare != 0) return priceCompare;
            return o1.getTimestamp().compareTo(o2.getTimestamp());
        });
        
        this.orderMap = new HashMap<>();
    }

    public void addOrder(Order order) {
        orderMap.put(order.getOrderId(), order);
        
        if (order.getType() == OrderType.BUY) {
            bids.offer(order);
        } else {
            asks.offer(order);
        }
    }

    public List<Trade> matchOrders() {
        List<Trade> trades = new ArrayList<>();
        
        while (!bids.isEmpty() && !asks.isEmpty()) {
            Order bestBid = bids.peek();  // Highest buy price
            Order bestAsk = asks.peek();  // Lowest sell price
            
            // Check if trade possible
            if (bestBid.getPrice() >= bestAsk.getPrice()) {
                int tradeQuantity = Math.min(bestBid.getQuantity(), bestAsk.getQuantity());
                double tradePrice = bestAsk.getPrice();
                
                // Create trade
                Trade trade = new Trade(bestBid.getOrderId(), bestAsk.getOrderId(), 
                                      symbol, tradeQuantity, tradePrice, bestBid.getTimestamp());
                trades.add(trade);
                
                // Update quantities
                bestBid.setQuantity(bestBid.getQuantity() - tradeQuantity);
                bestAsk.setQuantity(bestAsk.getQuantity() - tradeQuantity);
                
                // Remove filled orders
                if (bestBid.getQuantity() == 0) {
                    bids.poll();
                    orderMap.remove(bestBid.getOrderId());
                }
                if (bestAsk.getQuantity() == 0) {
                    asks.poll();
                    orderMap.remove(bestAsk.getOrderId());
                }
            } else {
                break; // No more matches
            }
        }
        
        return trades;
    }
}