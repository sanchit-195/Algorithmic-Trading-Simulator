package com.trading.reader;
import com.trading.model.*;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

public class CSVOrderReader {
    public List<Order> readOrders(String filename) throws IOException {
        List<Order> orders = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            boolean isHeader = true;
            
            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue; // Skip header
                }
                
                String[] fields = line.split(",");
                String orderId = fields[0].trim();
                OrderType type = OrderType.valueOf(fields[1].trim().toUpperCase());
                String symbol = fields[2].trim();
                int quantity = Integer.parseInt(fields[3].trim());
                double price = Double.parseDouble(fields[4].trim());
                LocalDateTime timestamp = LocalDateTime.parse(fields[5].trim());
                
                Order order = new LimitOrder(orderId, type, symbol, quantity, price, timestamp);
                orders.add(order);
            }
        }
        
        return orders;
    }
}