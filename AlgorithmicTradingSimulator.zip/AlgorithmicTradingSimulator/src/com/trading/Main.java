package com.trading;
import com.trading.engine.MatchingEngine;
import com.trading.model.Order;
import com.trading.reader.CSVOrderReader;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Algorithmic Trading Simulator ===");
        
        try {
            MatchingEngine engine = new MatchingEngine();
            CSVOrderReader reader = new CSVOrderReader();
            
            // CSV se orders padho
            List<Order> orders = reader.readOrders("orders.csv");
            System.out.println("Loaded " + orders.size() + " orders");
            
            // Sab orders process karo
            for (Order order : orders) {
                engine.placeOrder(order);
            }
            
            // Final results dikhao
            engine.printTradeLedger();
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}