package com.trading.model;
import java.time.LocalDateTime;

public class Trade {
    private static int tradeIdCounter = 1;
    
    private final String tradeId;
    private final String buyOrderId;
    private final String sellOrderId;
    private final String symbol;
    private final int quantity;
    private final double price;
    private final LocalDateTime timestamp;

    public Trade(String buyOrderId, String sellOrderId, String symbol, 
                int quantity, double price, LocalDateTime timestamp) {
        this.tradeId = "TRADE_" + tradeIdCounter++;
        this.buyOrderId = buyOrderId;
        this.sellOrderId = sellOrderId;
        this.symbol = symbol;
        this.quantity = quantity;
        this.price = price;
        this.timestamp = timestamp;
    }

    // Getter methods
    public String getTradeId() { return tradeId; }
    public String getBuyOrderId() { return buyOrderId; }
    public String getSellOrderId() { return sellOrderId; }
    public String getSymbol() { return symbol; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public LocalDateTime getTimestamp() { return timestamp; }

    // YEH METHOD ADD KARNA HAI (Solution)
    @Override
    public String toString() {
        return String.format("Trade[ID:%s, Buy:%s, Sell:%s, %s Qty:%d @ $%.2f, Time:%s]", 
                tradeId, buyOrderId, sellOrderId, symbol, quantity, price, timestamp);
    }
}