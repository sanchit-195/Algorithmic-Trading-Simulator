package com.trading.model;

import java.time.LocalDateTime;

public abstract class Order {
    protected String orderId;
    protected OrderType type;
    protected String symbol;
    protected int quantity;
    protected double price;
    protected LocalDateTime timestamp;
    protected boolean isCancelled;

    public Order(String orderId, OrderType type, String symbol, int quantity, 
                double price, LocalDateTime timestamp) {
        this.orderId = orderId;
        this.type = type;
        this.symbol = symbol;
        this.quantity = quantity;
        this.price = price;
        this.timestamp = timestamp;
        this.isCancelled = false;
    }

    // Getters
    public String getOrderId() { return orderId; }
    public OrderType getType() { return type; }
    public String getSymbol() { return symbol; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public boolean isCancelled() { return isCancelled; }
    
    // Setters
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void cancel() { this.isCancelled = true; }

    public abstract boolean isMarketOrder();

    @Override
    public String toString() {
        return String.format("Order[ID:%s, %s %s Qty:%d @ $%.2f, Time:%s]", 
                orderId, type, symbol, quantity, price, timestamp);
    }
}