package com.trading.model;

public enum OrderType {
    BUY, SELL
}