package com.trading.model;
import java.time.LocalDateTime;

public class LimitOrder extends Order {
    public LimitOrder(String orderId, OrderType type, String symbol, int quantity, 
                     double price, LocalDateTime timestamp) {
        super(orderId, type, symbol, quantity, price, timestamp);
    }

    @Override
    public boolean isMarketOrder() {
        return false;
    }
}